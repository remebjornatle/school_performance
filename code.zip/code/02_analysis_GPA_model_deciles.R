#remove files not in use
rm(list = setdiff(ls(), c("dat", "daar")))

#create deciles (stratified by gender and year)
dat = dat %>% 
  group_by(Gender, grad_year) %>% 
  mutate(gpa_dec = ntile(gpa_score, 10))

#simple Cox model only using gender and GPA
gpa_mod = coxph(Surv(lifetime, early_death) ~ gpa_dec*Gender, data = dat)

#create frame to attach predictions: predict number of events from graduation to 30-years old
gpa = dat %>% 
  ungroup() %>% 
  select(gpa_dec, Gender) %>% 
  group_by(gpa_dec,Gender) %>% 
  slice(1) %>% #one unique registration per group
  mutate(lifetime = 5110, #lifetime: 01/01/2019 - graduation_date, i.e. surviving until 30 yrs
         early_death = 0) 

#predict on frame
gpa_fit = predict(gpa_mod, type = "expected", newdata = gpa, se.fit = T)

#unlist to create 95% CIs
gpa_fit = gpa_fit %>% 
  map(unlist) %>% 
  as_data_frame() %>% 
  mutate(ul = fit + 2*se.fit,
         ll = fit - 2*se.fit)

#merge onto frame
gpa = bind_cols(gpa, gpa_fit)

##################################GPA GRAPH#####################################

#graph results
gpa %>% 
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls"))) %>% 
  filter(!is.na(gpa_dec)) %>% 
  ggplot(aes(x = reorder(gpa_dec, -fit), y = round(fit*10000,0),fill = Sex)) +
  geom_col(color = "black", width = 0.5, position = "dodge") +
  theme_bw() +
  geom_errorbar(aes(ymin=ll*10000, ymax=ul*10000),
                width=.2,                    # Width of the error bars
                position=position_dodge(.5)) +
  xlab("School GPA decile") +
  ylab("Events per 10 000") +
  scale_fill_lancet() +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggsave("tables and figures/GPA_cox_deciles.pdf",  width = 6, height = 4) 


###############################MODELS###########################################
dat$gpa_dec = factor(dat$gpa_dec, levels = c(10:1))
dat$par_wage = factor(dat$par_wage, levels = c("Par Inc Q4", "Par Inc Q3","Par Inc Q2","Par Inc Q1"))
dat$par_educ = factor(dat$par_educ, levels = c("Par Educ High Uni","Par Educ Low Uni","Par Educ Secondary","Par Educ Primary"))


####BOYS####

#full model
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_dec + par_educ + par_wage, 
                 data = dat[dat$Gender == "Boys",])

#GPA model
mod_boys_gpa = coxph(Surv(lifetime, early_death) ~ gpa_dec, 
                     data = dat[dat$Gender == "Boys",])

#Parental education model
mod_boys_educ = coxph(Surv(lifetime, early_death) ~ par_educ, 
                      data = dat[dat$Gender == "Boys",])

#Parental income model
mod_boys_inc = coxph(Surv(lifetime, early_death) ~ par_wage, 
                     data = dat[dat$Gender == "Boys",])

#Extract coefficients (multivariate)
mod1 = as.data.frame(exp(cbind(OR = coef(mod_boys), confint(mod_boys))))
mod1$names = row.names(mod1)
mod1$Gender = "Boys"
mod1$type = "Multivariate"

#Extract coefficients (bivariate)
mod1_gpa = as.data.frame(exp(cbind(OR = coef(mod_boys_gpa), confint(mod_boys_gpa))))
mod1_inc = as.data.frame(exp(cbind(OR = coef(mod_boys_inc), confint(mod_boys_inc))))
mod1_educ = as.data.frame(exp(cbind(OR = coef(mod_boys_educ), confint(mod_boys_educ))))

mod1_biv = bind_rows(mod1_gpa, mod1_inc, mod1_educ)
mod1_biv$names = row.names(mod1_biv)
mod1_biv$Gender = "Boys"
mod1_biv$type = "Bivariate"

####GIRLS####

#full model
mod_girls = coxph(Surv(lifetime, early_death) ~ gpa_dec + par_educ + par_wage, 
                  data = dat[dat$Gender == "Girls",])

#without GPA (for comparison)
mod_girls_gpa = coxph(Surv(lifetime, early_death) ~ gpa_dec, 
                      data = dat[dat$Gender == "Girls",])

mod_girls_educ = coxph(Surv(lifetime, early_death) ~ par_educ, 
                       data = dat[dat$Gender == "Girls",])

mod_girls_inc = coxph(Surv(lifetime, early_death) ~ par_wage, 
                      data = dat[dat$Gender == "Girls",])

#Extract coefficients (multivariate)
mod2 = as.data.frame(exp(cbind(OR = coef(mod_girls), confint(mod_girls))))
mod2$names = row.names(mod2)
mod2$Gender = "Girls"
mod2$type = "Multivariate"

#Extract coefficients (bivariate)
mod2_gpa = as.data.frame(exp(cbind(OR = coef(mod_girls_gpa), confint(mod_girls_gpa))))
mod2_inc = as.data.frame(exp(cbind(OR = coef(mod_girls_inc), confint(mod_girls_inc))))
mod2_educ = as.data.frame(exp(cbind(OR = coef(mod_girls_educ), confint(mod_girls_educ))))

mod2_biv = bind_rows(mod2_gpa, mod2_inc, mod2_educ)
mod2_biv$names = row.names(mod2_biv)
mod2_biv$Gender = "Girls"
mod2_biv$type = "Bivariate"


#put gogether
mods = bind_rows(mod2, mod1, mod1_biv, mod2_biv)

mods$names = gsub("gpa_dec","", mods$names)
mods$names = gsub("par_educ","", mods$names)
mods$names = gsub("par_wage","", mods$names)

###########################MODELS GRAPH#########################################

unique(mods$names)

#Fix naming: Add prefix "GPA Decile" if there is only 1 character
mods = mods %>% 
  mutate(names_fac = ifelse(nchar(names) == "1", paste0("GPA Decile",names), names))

mods %>% 
  filter(type == "Multivariate") %>% 
  mutate(Sex = factor(Gender, levels = c("Boys","Girls"), labels = c("Boys","Girls"))) %>% 
  ggplot(aes(x = names_fac, y = OR, color = Sex, group = Sex)) +
  geom_hline(yintercept = 1,  color = "grey") +
  geom_point(size=3, position = position_dodge(0.5)) +
  geom_errorbar(aes(ymin=`2.5 %`, ymax=`97.5 %`), 
                width=.3, 
                position= position_dodge(0.5)) +
  scale_color_lancet() +
  coord_flip(ylim = c(0, 6.5)) +
  theme_bw() +
  ylab("Hazard ratio") +
  xlab("") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) 
ggsave("tables and figures/Model_cox_mv_deciles.pdf",  width = 7, height = 6)

###########################MODELS TABLE#########################################

#GPA models
stargazer(mod_boys_gpa, mod_girls_gpa,
          ci=T, apply.coef = exp, ci.level = 0.95,
          digits=2, type = "text",
          star.char = "")

#Educ models
stargazer(mod_boys_educ, mod_girls_educ, 
          ci=T, apply.coef = exp, ci.level = 0.95,
          digits=2, type = "text",
          star.char = "")

#Income models
stargazer(mod_boys_inc, mod_girls_inc,
          ci=T, apply.coef = exp, ci.level = 0.95,
          digits=2, type = "text",
          star.char = "")

#Multivariate models
stargazer(mod_boys, mod_girls,
          ci=T, apply.coef = exp, ci.level = 0.95,
          digits=2, type = "text",
          star.char = "")


