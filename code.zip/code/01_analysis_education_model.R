###########################EDUC MODEL############################################
#comment: same steps as above, but parental education level
#FIGUR 2B

educ_mod = coxph(Surv(lifetime, early_death) ~ par_educ*Gender, data = dat)

educ = dat %>% 
  ungroup() %>% 
  select(par_educ, Gender) %>% 
  group_by(par_educ,Gender) %>% 
  slice(1) %>% 
  mutate(lifetime = 5110,
         early_death = 0) 

educ_fit = predict(educ_mod, type = "expected", newdata = educ, se.fit = T)

educ_fit = educ_fit %>% 
  map(unlist) %>% 
  as_data_frame() %>% 
  mutate(ul = fit + 2*se.fit,
         ll = fit - 2*se.fit)

educ = bind_cols(educ, educ_fit)


##################################EDU FIG#######################################

educ_plot = educ %>%
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls")),
         par_educ = factor(par_educ,
                           levels =  c("Par Educ High Uni", 
                                       "Par Educ Low Uni",
                                       "Par Educ Secondary",
                                       "Par Educ Primary"),
                           labels = c("High Uni","Low Uni","Secondary","Primary"))) %>% 
  filter(!is.na(par_educ)) %>% 
  ggplot(aes(x = reorder(par_educ,-fit), y = round(fit*10000,0), fill = Sex)) +
  geom_col(color = "black", width = 0.5, position = "dodge") +
  theme_bw() +
  geom_errorbar(aes(ymin=ll*10000, ymax=ul*10000),
                width=.2,                    # Width of the error bars
                position=position_dodge(.5)) +
  xlab("Parental education") +
  ylab("Events per 10 000") +
  scale_fill_lancet() +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"),
        legend.position = "none")
ggsave("tables and figures/Educ_cox.pdf",  width = 6, height = 4) 

##################################EDU TABLE#####################################

educ_tab = educ %>% 
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls")),
         par_educ = factor(par_educ,
                           levels =  c("Par Educ High Uni", 
                                       "Par Educ Low Uni",
                                       "Par Educ Secondary",
                                       "Par Educ Primary"),
                           labels = c("High Uni","Low Uni","Secondary","Primary"))) %>% 
  filter(!is.na(par_educ)) %>% 
  mutate(estimate = round(fit*10000,0),
         ul = round(ul*10000,0),
         ll = round(ll*10000,0)) %>% 
  select(par_educ, Gender, estimate, ll, ul)



#EXPORT
write.csv(educ_tab, "tables and figures/educ_tab.csv", row.names = F)

