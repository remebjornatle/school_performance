gpa_plots = gpa_plot +
  ggtitle('GPA quartile')

inc_plots = inc_plot +
  ggtitle('Parental income quartile') +
  theme(legend.position = "bottom")


educ_plots = educ_plot +
  ggtitle('Parental education')


patchwork <- gpa_plots + inc_plots + educ_plots

patchwork + plot_annotation(tag_levels = 'a') &
  theme(plot.tag = element_text(face = 'bold'))
ggsave("tables and figures/Figure1.pdf",  width = 10, height = 4) 
