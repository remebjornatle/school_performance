#remove files not in use
rm(list = setdiff(ls(), c("dat", "daar")))

##################################SIBLINGS####################################
#create GPA percentile stratified by cohort and gender
dat = dat %>% 
  group_by(grad_year, Gender) %>% 
  mutate(gpa_percentile = ntile(gpa_score, n =  100)) 

#reshuffle order of factors for the models to use consistent references
dat$gpa_q = factor(dat$gpa_q, levels = c("GPA Q4", "GPA Q3","GPA Q2","GPA Q1"))
dat$par_wage = factor(dat$par_wage, levels = c("Par Inc Q4", "Par Inc Q3","Par Inc Q2","Par Inc Q1"))
dat$par_educ = factor(dat$par_educ, levels = c("Par Educ High Uni","Par Educ Low Uni","Par Educ Secondary","Par Educ Primary"))


#SUBSET to mothers with > 1 child with GPA. WARNING - subsets data. Caution!
dat = dat %>% 
  group_by(mother_id) %>% 
  mutate(sibs = n()) %>% 
  filter(sibs > 1) %>% 
  mutate(fam_gpa = mean(gpa_percentile), 
         fam_gpa_adj = (fam_gpa*sibs-gpa_percentile)/(sibs-1)) #Average sibling GPA - control variable

dat$sibs = ifelse(dat$sibs > 10, NA, dat$sibs) # set as missing if > 10 sibs

###################BOYS

#full model: benchmark
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                 data = dat[dat$Gender == "Boys" & dat$sibs > 1,])

#with family frailty 
mod_boys_fam = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage + fam_gpa + 
                       frailty(mother_id), #FRAILTY HERE
                     data = dat[dat$Gender == "Boys" & dat$sibs > 1,])

###################GIRLS
#full model
mod_girls = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                  data = dat[dat$Gender == "Girls" & dat$sibs > 1,])

#with family frailty 
mod_girls_fam = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage + fam_gpa + 
                        frailty(mother_id), #FRAILTY HERE
                      data = dat[dat$Gender == "Girls" & dat$sibs > 1,])

#Extract coefficients from the models
mod1 = as.data.frame(exp(cbind(OR = coef(mod_boys), confint(mod_boys))))
mod1$names = row.names(mod1)
mod1$Gender = "Boys"

mod2 = as.data.frame(exp(cbind(OR = coef(mod_boys_fam), confint(mod_boys_fam))))
mod2$names = row.names(mod2)
mod2$Gender = "Boys_fam"

mod3 = as.data.frame(exp(cbind(OR = coef(mod_girls), confint(mod_girls))))
mod3$names = row.names(mod3)
mod3$Gender = "Girls"

mod4 = as.data.frame(exp(cbind(OR = coef(mod_girls_fam), confint(mod_girls_fam))))
mod4$names = row.names(mod4)
mod4$Gender = "Girls_fam"


####MERGE RESULTS###

mods = bind_rows(mod1, mod2, mod3, mod4)


mods$names = gsub("gpa_q","", mods$names)
mods$names = gsub("par_educ","", mods$names)
mods$names = gsub("par_wage","", mods$names)

#graph results
mods %>% 
  filter(names != "fam_gpa") %>% 
  mutate(Sex = factor(Gender, levels = c("Boys","Boys_fam","Girls", "Girls_fam"), 
                      labels = c("Boys","Boys, within-family", "Girls", "Girls, within-family"))) %>% 
  ggplot(aes(x = names, y = OR, color = Sex, group = Sex)) +
  geom_hline(yintercept = 1,  color = "grey") +
  geom_point(size=2, position = position_dodge(0.7)) +
  geom_errorbar(aes(ymin=`2.5 %`, ymax=`97.5 %`), 
                width=.3, 
                position= position_dodge(0.7)) +
  scale_color_lancet() +
  coord_flip(ylim = c(0,4.1)) +
  theme_bw() +
  ylab("Hazard ratio") +
  xlab("") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) 
ggsave("tables and figures/Model_cox_within.pdf",  width = 7, height = 4)

#CREATE TABLE

#count number of observations
n_mod_boys = mod_boys$n
n_mod_boys_fam = mod_boys_fam$n
n_mod_girls = mod_girls$n
n_mod_girls_fam = mod_girls_fam$n

#put together and clean up HR and 95% CIs
mods = mods %>% 
  mutate(HR = round(OR,2),
         `2.5 %` = round(`2.5 %`, 2),
         `97.5 %` = round(`97.5 %`,2),
         est = paste0(HR, "[",`2.5 %`,",",`97.5 %`,"]")) %>% 
  select(names, Gender, est)

#pivot wide for better shape
mods = mods %>%  
  pivot_wider(names_from = Gender, 
              values_from = est)

#create row with number of observations
N = data.frame(colnames(mods),c("N",n_mod_boys,n_mod_boys_fam,n_mod_girls,n_mod_girls_fam))
names(N) = c("var", "val")
N = N %>%  pivot_wider(names_from = var,
                       values_from = val)

mods = bind_rows(mods, N)

write.csv(mods, "tables and figures/sib_tab.csv", row.names = F)