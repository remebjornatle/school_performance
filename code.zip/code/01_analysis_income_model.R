###########################INC MODEL############################################
#comment: same steps as above, but household income
#FIGURE 2B

inc_mod = coxph(Surv(lifetime, early_death) ~ par_wage*Gender, data = dat)

inc = dat %>% 
  ungroup() %>% 
  select(par_wage, Gender) %>% 
  group_by(par_wage,Gender) %>% 
  slice(1) %>% 
  mutate(lifetime = 5110,
         early_death = 0) 

inc_fit = predict(inc_mod, type = "expected", newdata = inc, se.fit = T)

inc_fit = inc_fit %>% 
  map(unlist) %>% 
  as_data_frame() %>% 
  mutate(ul = fit + 2*se.fit,
         ll = fit - 2*se.fit)

inc = bind_cols(inc, inc_fit)

##################################INC FIG#######################################

inc_plot = inc %>% 
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls")),
         par_wage = factor(par_wage,
                           levels =  c("Par Inc Q1", 
                                       "Par Inc Q2",
                                       "Par Inc Q3",
                                       "Par Inc Q4"),
                           labels = c("Q1","Q2","Q3","Q4"))) %>%
  filter(!is.na(par_wage)) %>% 
  ggplot(aes(x = reorder(par_wage,-fit), y = round(fit*10000,0),fill = Sex)) +
  geom_col(color = "black", width = 0.5, position = "dodge") +
  theme_bw() +
  geom_errorbar(aes(ymin=ll*10000, ymax=ul*10000),
                width=.2,                    # Width of the error bars
                position=position_dodge(.5)) +
  xlab("Parental income quartile") +
  ylab("Events per 10 000") +
  scale_fill_lancet() +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggsave("tables and figures/Inc_cox.pdf",  width = 6, height = 4) 


##################################INC TABLE#####################################

inc_tab = inc %>% 
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls")),
         par_wage = factor(par_wage,
                           levels =  c("Par Inc Q1", 
                                       "Par Inc Q2",
                                       "Par Inc Q3",
                                       "Par Inc Q4"),
                           labels = c("Q1","Q2","Q3","Q4"))) %>%
  filter(!is.na(par_wage)) %>% 
  mutate(estimate = round(fit*10000,0),
         ul = round(ul*10000,2),
         ll = round(ll*10000,2)) %>% 
  select(par_wage, Gender, estimate, ll, ul)

write.csv(inc_tab, "tables and figures/inc_tab.csv", row.names = F)    
