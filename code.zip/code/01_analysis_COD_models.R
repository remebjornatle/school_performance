
#remove files not in use
rm(list = setdiff(ls(), c("dat", "daar")))

#############################FIG 3##############################################

#prepare for a merge into daar - simplify dataframe to avoid later problems of duplication
df = dat %>% select(pid, gpa_q, Gender)

#load table of descriptions
cod_descriptions = read.csv2("data/cod_data.csv")

#simplify
cod_decriptions = cod_descriptions %>% 
  select(Code, Description)

#rename variable in cause of death register - to generic name
daar$Desc = daar$cod

#merge-in person characteristics from main data file
daar = daar %>% 
  left_join(df, by = c("pid"))

#count by gender, GPA Qs and meta-type
daar_counts = daar %>% 
  group_by(gpa_q, Gender) %>% 
  mutate(tot = n()) %>% 
  group_by(gpa_q, Desc, Gender, tot) %>% 
  count() %>%
  mutate(share = n/tot) 

dat_counts = dat %>% 
  group_by(gpa_q, Gender) %>% 
  count() %>% 
  rename(n_tot = n)

library(RColorBrewer)
nb.cols <- 18
mycolors <- colorRampPalette(brewer.pal(8, "Set1"))(nb.cols)

#create figure 3
daar_counts %>% 
  left_join(dat_counts, by = c("Gender", "gpa_q")) %>% 
  mutate(n = n/(n_tot/10000)) %>% 
  mutate(Desc = ifelse(is.na(Desc), "Unknown", Desc)) %>% 
  mutate(gpa_q = factor(gpa_q,
                        levels =  c("GPA Q1", 
                                    "GPA Q2",
                                    "GPA Q3",
                                    "GPA Q4"),
                        labels = c("Q1","Q2","Q3","Q4"))) %>% 
  ggplot(aes(x = gpa_q, y = n, fill = factor(Desc))) +
  geom_bar(position = "stack", stat = "identity", color = "black", width = 0.5, alpha = 1) +
  scale_fill_brewer(palette = "RdYlBu", name = "Cause of death") +
  facet_wrap(~Gender) +
  ylab("Events per 10 000") +
  xlab("School GPA quartile") +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggsave("tables and figures/Fig3.pdf",  width = 10, height = 4) 

#table the results (fig 3)
cod_tab = 
  daar_counts %>% 
  ungroup() %>% 
  left_join(dat_counts, by = c("Gender", "gpa_q")) %>% 
  mutate(n = n/(n_tot/10000)) %>% 
  select(gpa_q, Gender, n, Desc) %>% 
  mutate(gpa_q = factor(gpa_q,
                        levels =  c("GPA Q1", 
                                    "GPA Q2",
                                    "GPA Q3",
                                    "GPA Q4"),
                        labels = c("Q1","Q2","Q3","Q4"))) %>% 
  mutate(n = round(n,2)) %>% 
  pivot_wider(names_from = 'Gender', values_from = 'n') 

write.csv(cod_tab, "tables and figures/cod_tab.csv", row.names = F)

########################Fig 4###################################################

#create subframe focusing on "External causes of injury and poisoning"
daar_temp = daar %>% 
  left_join(cod_descriptions, by = "Code") %>% #merge in detailed descriptions 
  filter(cod == "External causes of injury and poisoning") %>% 
  select(pid, Description, Code)

#count types: 
cod_count = daar_temp %>% 
  group_by(Description) %>% 
  count()
write.csv(cod_count, "tables and figures/cod_count.csv", row.names = F)

#reprogram some categories to simplify
daar_temp = daar_temp %>% 
  mutate(Description_old = Description,
         Description = case_when(
           Description == "Accidents" ~ "Other accidents or undetermined",
           Description == "Alcohol abuse (including alcoholic psychosis)" ~ "Poisoning",
           Description == "Drug dependence, toxicomania" ~ "Poisoning",
           Description == "Events of undetermined intent" ~ "Other accidents or undetermined",
           Description == "Homicide, assault" ~ "Violent causes",
           Description == "of which Accidental falls" ~ "Fall accidents",
           Description == "of which Accidental poisoning" ~ "Poisoning",
           Description == "of which Transport accidents" ~ "Traffic accidents",
           Description == "External causes of injury and poisoning" ~ "Other accidents or undetermined",
           ))

#minimal version of main file
dat_temp = dat %>% 
  select(pid, gpa_q, lifetime, Gender)

#merge
dat_temp = dat_temp %>% 
  left_join(daar_temp, by = c("pid"))

#create marker for lowest quartile ("perc" is numerical)
dat_temp$Q1 = ifelse(dat_temp$gpa_q == "GPA Q1", 1, 0)

#simplify
dat_temp = dat_temp %>% 
  select(pid, lifetime, Gender, Q1, Code, Description)

#dummify causes of death
dummies = dummy_cols(dat_temp$Description)

#missing = 0 + remove missing-dummies
dummies[is.na(dummies)] = 0
dummies = dummies %>% select(-.data_NA)

#attach cause of death dummies 
dat_temp = bind_cols(dat_temp, dummies)

#create a frame to attach to
frame = data.frame(HR = numeric(),
                   kjoenn = numeric(),
                   nobs = numeric())

#create corresponding numeric variable in dataset
dat_temp$kjoenn = ifelse(dat_temp$Gender == "Boys",1,2)

#list of causes to loop over
list = colnames(dat_temp)[grepl(".data_",colnames(dat_temp))]

for (i in 1:length(list)) {
  
  cause_name = list[i]
  
  #find column with cause names
  cause = dat_temp[,colnames(dat_temp) == cause_name]
  
  #attach with generic name
  dat_temp = cbind(dat_temp, cause)
  colnames(dat_temp)[ncol(dat_temp)] = "temp_cause"
  
  #estimate models
  mod_temp_boys = coxph(Surv(lifetime, temp_cause) ~ Q1, 
                        data = dat_temp[dat_temp$kjoenn == 1,])
  
  mod_temp_girls = coxph(Surv(lifetime, temp_cause) ~ Q1, 
                         data = dat_temp[dat_temp$kjoenn == 2,])
  
  #store coefficients and necessary data
  temp = as.data.frame(exp(cbind(HR = coef(mod_temp_boys), confint(mod_temp_boys))))
  temp$kjoenn = 1
  temp$type = cause_name
  temp$nobs = summary(mod_temp_boys)$n
  
  frame = bind_rows(frame, temp)
  
  temp = as.data.frame(exp(cbind(HR = coef(mod_temp_girls), confint(mod_temp_girls))))
  temp$kjoenn = 2
  temp$type = cause_name
  temp$nobs = summary(mod_temp_girls)$n
  
  frame = bind_rows(frame, temp)
  
  #remove temp columns
  dat_temp = dat_temp %>% select(-temp_cause)
  
  #repeat
}

#graph it 
frame %>% 
  mutate(type = substr(type,7,nchar(type))) %>% 
  mutate(Sex = factor(kjoenn, levels = c(1,2), labels = c("Boys", "Girls"))) %>% 
  ggplot(aes(x = reorder(type, HR), y = HR, color = Sex, group = Sex)) +
  geom_hline(yintercept = 1,  color = "grey") +
  geom_point(size=3, position = position_dodge(0.5)) +
  geom_errorbar(aes(ymin=`2.5 %`, ymax=`97.5 %`), 
                width=.3, 
                position= position_dodge(0.5)) +
  #scale_color_brewer(palette = "Set1", name = "Gender") +
  scale_color_lancet() +
  coord_flip() +
  theme_bw() +
  ylab("Hazard ratio") +
  xlab("") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) 
ggsave("tables and figures/cod_HR.pdf",  width = 7, height = 3.5) 

#table it
tab_cod2 =  frame %>% 
  mutate(type = substr(type,7,nchar(type))) %>% 
  mutate(Gender = factor(kjoenn, levels = c(2,1), labels = c("Girls", "Boys"))) %>% 
  select(type, Gender, HR, `2.5 %`, `97.5 %`) %>% 
  mutate(HR = round(HR,2),
         `2.5 %` = round(`2.5 %`,2),
         `97.5 %` = round(`97.5 %`,2),
         `95% CI` = paste0("[", `2.5 %`,",", `97.5 %`,"]")) %>% 
  select(type, Gender, HR, `95% CI`) %>% 
  rename(`Cause of death` = type,
         `Hazard ratio` = HR) %>% 
  arrange(Gender)

write.csv(tab_cod2, "tables and figures/cod_tabHR.csv", row.names = F)
