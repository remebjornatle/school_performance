
#remove files not in use
rm(list = setdiff(ls(), c("dat", "daar")))

#create factors
dat$gpa_q = factor(dat$gpa_q, levels = c("GPA Q4", "GPA Q3","GPA Q2","GPA Q1"))
dat$par_wage = factor(dat$par_wage, levels = c("Par Inc Q4", "Par Inc Q3","Par Inc Q2","Par Inc Q1"))
dat$par_educ = factor(dat$par_educ, levels = c("Par Educ High Uni","Par Educ Low Uni","Par Educ Secondary","Par Educ Primary"))

summary(dat$lifetime)

#Store original: we will reprogram this variable according to the median timeframe
dat$lifetime_store = dat$lifetime
dat$early_death_store = dat$early_death

#create dataframe for storing number of observations in each model
nobs = data.frame(model = as.character(),
                  nobs = as.numeric())

############################First period########################################

median = median(dat$lifetime)

#EARLY VERSION: reprogram
# 1) lifetime set to median if lifetime > median
# 2) early death set to 0 if death occured after median
dat = dat %>% 
  mutate(lifetime_store = lifetime,
         early_death_store = early_death,
         lifetime = ifelse(lifetime > median, median, lifetime),
         early_death = ifelse(early_death == 1 & lifetime > median,0, early_death))

####BOYS####

#model
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                 data = dat[dat$Gender == "Boys",])

#Extract coefficients
mod1 = as.data.frame(exp(cbind(OR = coef(mod_boys), confint(mod_boys))))
mod1$names = row.names(mod1)
mod1$Gender = "Boys"
mod1$type = "Multivariate"

####GIRLS####

#model
mod_girls = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                  data = dat[dat$Gender == "Girls",])

##Extract coefficients
mod2 = as.data.frame(exp(cbind(OR = coef(mod_girls), confint(mod_girls))))
mod2$names = row.names(mod2)
mod2$Gender = "Girls"
mod2$type = "Multivariate"

####MERGE###
mods = bind_rows(mod2, mod1)

#store results (used for storing number of observations)
early_boys_n = summary(mod_boys)$n
early_girls_n = summary(mod_girls)$n

###########################STORE################################################

unique(mods$names)

mods$names_fac = factor(mods$names,
                        levels = c("GPA Q1","GPA Q2","GPA Q3",
                                   "Par Educ Primary","Par Educ Secondary","Par Educ Low Uni",
                                   "Par Inc Q1","Par Inc Q2","Par Inc Q3")) 

mods_early = mods

#clear out dfs
rm(list=ls(pattern="mod_"))

###################Reinitialize#################################################

dat$lifetime = dat$lifetime_store
dat$early_death = dat$early_death_store

######################Setup late version########################################

#LATE VERSION
#EARLY VERSION: reprogram
# 1) lifetime set NA if lifetime < median
# 2) early death set to NA if death occured before median
dat = dat %>% 
  mutate(lifetime_store = lifetime,
         early_death_store = early_death,
         lifetime = ifelse(lifetime < median, NA, lifetime),
         early_death = ifelse(early_death == 1 & lifetime < median,NA, early_death))

####BOYS####

#model
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                 data = dat[dat$Gender == "Boys",])

#store results (used for storing number of observations)
mod1 = as.data.frame(exp(cbind(OR = coef(mod_boys), confint(mod_boys))))
mod1$names = row.names(mod1)
mod1$Gender = "Boys"
mod1$type = "Multivariate"

####GIRLS####

#model
mod_girls = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                  data = dat[dat$Gender == "Girls",])

#store results (used for storing number of observations)
mod2 = as.data.frame(exp(cbind(OR = coef(mod_girls), confint(mod_girls))))
mod2$names = row.names(mod2)
mod2$Gender = "Girls"
mod2$type = "Multivariate"

mods = bind_rows(mod2, mod1)

#store results
late_boys_n = summary(mod_boys)$n
late_girls_n = summary(mod_girls)$n

###########################MODELS GRAPH#########################################

unique(mods$names)

mods$names_fac = factor(mods$names,
                        levels = c("GPA Q1","GPA Q2","GPA Q3",
                                   "Par Educ Primary","Par Educ Secondary","Par Educ Low Uni",
                                   "Par Inc Q1","Par Inc Q2","Par Inc Q3")) 

mods_late = mods

mods_early$model = "Early"
mods_late$model = "Late"

#bind together
models = bind_rows(mods_early, mods_late)

#NOTE: can do both bivariate and multivariate
models %>% 
  filter(type == "Multivariate") %>% #FILTER HERE!
  filter(grepl("GPA", x = names)) %>% 
  mutate(names = gsub("gpa_q", "",names)) %>% 
  mutate(Sex = factor(Gender, levels = c("Boys","Girls"), labels = c("Boys","Girls"))) %>% 
  ggplot(aes(x = factor(names), y = OR, color = factor(model), group = factor(model))) +
  geom_hline(yintercept = 1,  color = "grey") +
  geom_point(size=3, position = position_dodge(0.5)) +
  geom_errorbar(aes(ymin=`2.5 %`, ymax=`97.5 %`), 
                width=.3, 
                position= position_dodge(0.5)) +
  scale_color_brewer(palette = "Set1", name = "Period used") +
  coord_flip(ylim = c(0,7)) +
  theme_bw() +
  ylab("Hazard ratio") +
  xlab("") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  facet_wrap(~Gender)
ggsave("tables and figures/Model_cox_mv_median_split.pdf",  width = 8, height = 3.5)

##################################Reinitialize##################################
dat$lifetime = dat$lifetime_store
dat$early_death = dat$early_death_store
