
#remove files not in use
rm(list = setdiff(ls(), c("dat", "daar")))

#reshuffle factors to create consistent references when modelling
dat$gpa_q = factor(dat$gpa_q, levels = c("GPA Q4", "GPA Q3","GPA Q2","GPA Q1"))
dat$par_wage = factor(dat$par_wage, levels = c("Par Inc Q4", "Par Inc Q3","Par Inc Q2","Par Inc Q1"))
dat$par_educ = factor(dat$par_educ, levels = c("Par Educ High Uni","Par Educ Low Uni","Par Educ Secondary","Par Educ Primary"))


#subset to boys only, since these scores do not exist for the full population of girls
dat_boys = dat %>% 
  filter(Gender == "Boys") 

#create stanine score into factor for each for the 9 levels
dat_boys$stanine = factor(dat_boys$stanine_score, 
                          levels = c(9:1))

#Model including cognitve scores
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage + stanine, 
                 data = dat_boys)

#A benchmark model using the same subsample
mod_boys_bench = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                       data = dat_boys[!is.na(dat_boys$stanine),])

#store results in data frames
temp = as.data.frame(exp(cbind(HR = coef(mod_boys), confint(mod_boys))))
temp_bench = as.data.frame(exp(cbind(HR = coef(mod_boys_bench), confint(mod_boys_bench))))

#Create figure for the results from the model including stanines scores
temp %>% 
  mutate(names = rownames(.),
         names = gsub("par_wage","", names),
         names = gsub("par_educ","", names),
         names = gsub("stanine","Cognitive score = ", names),
         names = gsub("gpa_q","", names),
  ) %>% 
  mutate(names = factor(names)) %>% 
  ggplot(aes(x = names, y = HR)) +
  geom_hline(yintercept = 1,  color = "grey") +
  geom_point(size=3, position = position_dodge(0.5)) +
  geom_errorbar(aes(ymin=`2.5 %`, ymax=`97.5 %`), 
                width=.3, 
                position= position_dodge(0.5)) +
  #scale_color_brewer(palette = "Set1", name = "Gender") +
  scale_color_lancet() +
  coord_flip(ylim = c(0.5, 5)) +
  theme_bw() +
  ylab("Hazard ratio") +
  xlab("") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) 
ggsave("tables and figures/stanine_mod.pdf",  width = 7, height = 4)

#create a corresponding table for the model including stanine scores
iq_tab = 
  temp %>% 
  mutate(names = rownames(.),
         names = gsub("par_wage","", names),
         names = gsub("par_educ","", names),
         names = gsub("stanine","Cognitive score = ", names),
         names = gsub("gpa_q","", names),
  ) %>% 
  mutate(HR = round(HR,2),
         `2.5 %` = round(`2.5 %`,2),
         `97.5 %` = round(`97.5 %`,2),
         `95% CI` = paste0("[", `2.5 %`,",", `97.5 %`,"]")) %>% 
  select(names, HR, `95% CI`) 
write.csv2(iq_tab, "tables and figures/stanine_tab.csv", row.names = F)

#create table with both models
stargazer(mod_boys, mod_boys_bench,
          ci=T, apply.coef = exp, ci.level = 0.95,
          digits=2, type = "text",
          star.char = "",
          out = "tables and figures/mod_boys_stanine_HRs.htm")
