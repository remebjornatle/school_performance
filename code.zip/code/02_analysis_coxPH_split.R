###############################MODELS###########################################

dat$gpa_q = factor(dat$gpa_q, levels = c("GPA Q4", "GPA Q3","GPA Q2","GPA Q1"))
dat$par_wage = factor(dat$par_wage, levels = c("Par Inc Q4", "Par Inc Q3","Par Inc Q2","Par Inc Q1"))
dat$par_educ = factor(dat$par_educ, levels = c("Par Educ High Uni","Par Educ Low Uni","Par Educ Secondary","Par Educ Primary"))

summary(dat$lifetime)


#Store original
dat$lifetime_store = dat$lifetime
dat$early_death_store = dat$early_death


############################Setup early version#################################

#EARLY VERSION
dat = dat %>% 
  mutate(lifetime_store = lifetime,
         early_death_store = early_death,
         lifetime = ifelse(lifetime > 3136, 3136, lifetime),
         early_death = ifelse(early_death == 1 & lifetime > 3136,0, early_death))


####BOYS####

#full model
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                 data = dat[dat$Gender == "Boys",])

#GPA model
mod_boys_gpa = coxph(Surv(lifetime, early_death) ~ gpa_q, 
                     data = dat[dat$Gender == "Boys",])

#Parental education model
mod_boys_educ = coxph(Surv(lifetime, early_death) ~ par_educ, 
                      data = dat[dat$Gender == "Boys",])

#Parental income model
mod_boys_inc = coxph(Surv(lifetime, early_death) ~ par_wage, 
                     data = dat[dat$Gender == "Boys",])

#FULL MODEL
mod1 = as.data.frame(exp(cbind(OR = coef(mod_boys), confint(mod_boys))))
mod1$names = row.names(mod1)
mod1$Gender = "Boys"
mod1$type = "Multivariate"

#BIVAR MODEL
mod1_gpa = as.data.frame(exp(cbind(OR = coef(mod_boys_gpa), confint(mod_boys_gpa))))
mod1_inc = as.data.frame(exp(cbind(OR = coef(mod_boys_inc), confint(mod_boys_inc))))
mod1_educ = as.data.frame(exp(cbind(OR = coef(mod_boys_educ), confint(mod_boys_educ))))

mod1_biv = bind_rows(mod1_gpa, mod1_inc, mod1_educ)
mod1_biv$names = row.names(mod1_biv)
mod1_biv$Gender = "Boys"
mod1_biv$type = "Bivariate"

####GIRLS####

#full model
mod_girls = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                  data = dat[dat$Gender == "Girls",])

#without GPA (for comparison)
mod_girls_gpa = coxph(Surv(lifetime, early_death) ~ gpa_q, 
                      data = dat[dat$Gender == "Girls",])

mod_girls_educ = coxph(Surv(lifetime, early_death) ~ par_educ, 
                       data = dat[dat$Gender == "Girls",])

mod_girls_inc = coxph(Surv(lifetime, early_death) ~ par_wage, 
                      data = dat[dat$Gender == "Girls",])

#FULL MODEL
mod2 = as.data.frame(exp(cbind(OR = coef(mod_girls), confint(mod_girls))))
mod2$names = row.names(mod2)
mod2$Gender = "Girls"
mod2$type = "Multivariate"


#BIVAR MODEL
mod2_gpa = as.data.frame(exp(cbind(OR = coef(mod_girls_gpa), confint(mod_girls_gpa))))
mod2_inc = as.data.frame(exp(cbind(OR = coef(mod_girls_inc), confint(mod_girls_inc))))
mod2_educ = as.data.frame(exp(cbind(OR = coef(mod_girls_educ), confint(mod_girls_educ))))

mod2_biv = bind_rows(mod2_gpa, mod2_inc, mod2_educ)
mod2_biv$names = row.names(mod2_biv)
mod2_biv$Gender = "Girls"
mod2_biv$type = "Bivariate"


####MERGE###
#this does not include "without results" - those are only implemented in table, so far

mods = bind_rows(mod2, mod1, mod1_biv, mod2_biv)

mods$names = gsub("gpa_q","", mods$names)
mods$names = gsub("par_educ","", mods$names)
mods$names = gsub("par_wage","", mods$names)

###########################MODELS GRAPH#########################################

unique(mods$names)

mods$names_fac = factor(mods$names,
                        levels = c("GPA Q1","GPA Q2","GPA Q3",
                                   "Par Educ Primary","Par Educ Secondary","Par Educ Low Uni",
                                   "Par Inc Q1","Par Inc Q2","Par Inc Q3")) 

mods_early = mods

#clear out dfs
rm(list=ls(pattern="mod_"))
rm(list=ls(pattern="mod1"))
rm(list=ls(pattern="mod2"))
rm(mods)

###################Reinitialize#################################################

dat$lifetime = dat$lifetime_store
dat$early_death = dat$early_death_store

######################Setup late version########################################

#LATE VERSION
dat = dat %>% 
  mutate(lifetime_store = lifetime,
         early_death_store = early_death,
         lifetime = ifelse(lifetime < 3136, NA, lifetime),
         early_death = ifelse(early_death == 1 & lifetime < 3136,NA, early_death))

####BOYS####

#full model
mod_boys = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                 data = dat[dat$Gender == "Boys",])

#GPA model
mod_boys_gpa = coxph(Surv(lifetime, early_death) ~ gpa_q, 
                     data = dat[dat$Gender == "Boys",])

#Parental education model
mod_boys_educ = coxph(Surv(lifetime, early_death) ~ par_educ, 
                      data = dat[dat$Gender == "Boys",])

#Parental income model
mod_boys_inc = coxph(Surv(lifetime, early_death) ~ par_wage, 
                     data = dat[dat$Gender == "Boys",])

#FULL MODEL
mod1 = as.data.frame(exp(cbind(OR = coef(mod_boys), confint(mod_boys))))
mod1$names = row.names(mod1)
mod1$Gender = "Boys"
mod1$type = "Multivariate"

#BIVAR MODEL
mod1_gpa = as.data.frame(exp(cbind(OR = coef(mod_boys_gpa), confint(mod_boys_gpa))))
mod1_inc = as.data.frame(exp(cbind(OR = coef(mod_boys_inc), confint(mod_boys_inc))))
mod1_educ = as.data.frame(exp(cbind(OR = coef(mod_boys_educ), confint(mod_boys_educ))))

mod1_biv = bind_rows(mod1_gpa, mod1_inc, mod1_educ)
mod1_biv$names = row.names(mod1_biv)
mod1_biv$Gender = "Boys"
mod1_biv$type = "Bivariate"

####GIRLS####

#full model
mod_girls = coxph(Surv(lifetime, early_death) ~ gpa_q + par_educ + par_wage, 
                  data = dat[dat$Gender == "Girls",])

#without GPA (for comparison)
mod_girls_gpa = coxph(Surv(lifetime, early_death) ~ gpa_q, 
                      data = dat[dat$Gender == "Girls",])

mod_girls_educ = coxph(Surv(lifetime, early_death) ~ par_educ, 
                       data = dat[dat$Gender == "Girls",])

mod_girls_inc = coxph(Surv(lifetime, early_death) ~ par_wage, 
                      data = dat[dat$Gender == "Girls",])

#FULL MODEL
mod2 = as.data.frame(exp(cbind(OR = coef(mod_girls), confint(mod_girls))))
mod2$names = row.names(mod2)
mod2$Gender = "Girls"
mod2$type = "Multivariate"


#BIVAR MODEL
mod2_gpa = as.data.frame(exp(cbind(OR = coef(mod_girls_gpa), confint(mod_girls_gpa))))
mod2_inc = as.data.frame(exp(cbind(OR = coef(mod_girls_inc), confint(mod_girls_inc))))
mod2_educ = as.data.frame(exp(cbind(OR = coef(mod_girls_educ), confint(mod_girls_educ))))

mod2_biv = bind_rows(mod2_gpa, mod2_inc, mod2_educ)
mod2_biv$names = row.names(mod2_biv)
mod2_biv$Gender = "Girls"
mod2_biv$type = "Bivariate"


####MERGE###
#this does not include "without results" - those are only implemented in table, so far

mods = bind_rows(mod2, mod1, mod1_biv, mod2_biv)

mods$names = gsub("gpa_q","", mods$names)
mods$names = gsub("par_educ","", mods$names)
mods$names = gsub("par_wage","", mods$names)



###########################MODELS GRAPH#########################################

unique(mods$names)

mods$names_fac = factor(mods$names,
                        levels = c("GPA Q1","GPA Q2","GPA Q3",
                                   "Par Educ Primary","Par Educ Secondary","Par Educ Low Uni",
                                   "Par Inc Q1","Par Inc Q2","Par Inc Q3")) 

mods_late = mods

mods_early$model = "Early"
mods_late$model = "Late"

models = bind_rows(mods_early, mods_late)

#NOTE: can do both bivariate and multivariate
models %>% 
  filter(type == "Multivariate") %>% #FILTER HERE!
  filter(grepl("GPA", x = names)) %>% 
  mutate(Sex = factor(Gender, levels = c("Boys","Girls"), labels = c("Boys","Girls"))) %>% 
  ggplot(aes(x = names_fac, y = OR, color = factor(model), group = factor(model))) +
  geom_hline(yintercept = 1,  color = "grey") +
  geom_point(size=3, position = position_dodge(0.5)) +
  geom_errorbar(aes(ymin=`2.5 %`, ymax=`97.5 %`), 
                width=.3, 
                position= position_dodge(0.5)) +
  scale_color_brewer(palette = "Set1", name = "Period used") +
  coord_flip(ylim = c(0.62, 7)) +
  theme_bw() +
  ylab("Hazard ratio") +
  xlab("") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  facet_wrap(~Gender)
#ggsave("tables and figures/Model_cox_mv_median_split.pdf",  width = 8, height = 3.5)

##################################Reinitialize##################################
dat$lifetime = dat$lifetime_store
dat$early_death = dat$early_death_store
