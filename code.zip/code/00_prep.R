#################################Preparations################################
#comment: this code block ("Preparations") - until line 32  
#(i) all packages are installed
#(ii) prepares for running the analysis
#(iii) creates simulated data

#list of packages needed
load.lib<-c("tidyverse", "vroom", "survival",
            "ggsci", "stargazer", "RColorBrewer",
            "here", "fastDummies", "patchwork")

#find packages not already installed
install.lib <- load.lib[!load.lib %in% installed.packages()]

#Install the missing packages, including their dependency.
for(lib in install.lib) install.packages(lib,dependencies=TRUE)

#Load all packages.
sapply(load.lib,require,character=TRUE)

nb.cols <- 18
mycolors <- colorRampPalette(brewer.pal(8, "Set1"))(nb.cols)


#set WD to current folder
setwd(here())

#create artificial data
source("00_create_artificial_data.R") #run code
#file.edit("00_create_artificial_data.R") #run this to view code
