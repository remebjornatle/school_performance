
set.seed(1254)

#number of observations
nobs = 100000

#create ID vector
dat = data.frame(
  pid = 1:nobs
)

#create gender
dat$Gender = sample(1:2, nobs, replace = T)
dat$Gender = factor(dat$Gender, levels = c(1,2), labels = c("Boys", "Girls"))

#create binary early death
dat$early_death = rbinom(nobs,size=1,prob=0.01)

#create lifetime variable
dat$lifetime = rnorm(nobs, mean=500, sd=50)

#create school performance quartiles
dat$gpa_q = sample(1:4, nobs, replace = T)
dat$gpa_q = factor(dat$gpa_q, levels = c(1,2,3,4), labels = c("GPA Q1", "GPA Q2", "GPA Q3", "GPA Q4"))

#create parental income quartiles
dat$par_wage = sample(1:4, nobs, replace = T)
dat$par_wage = factor(dat$par_wage, levels = c(1,2,3,4), labels = c("Par Inc Q1", "Par Inc Q2","Par Inc Q3","Par Inc Q4"))

#create parental school performance groups
dat$par_educ = sample(1:4, nobs, replace = T)
dat$par_educ = factor(dat$par_educ, levels = c(1,2,3,4), labels = c("Par Educ Primary",
                                                                   "Par Educ Secondary",
                                                                   "Par Educ Low Uni",
                                                                   "Par Educ High Uni"))
#create school cohort variable
dat$grad_year = sample(2002:2017, nobs, replace = T)

#create school performance score
dat$gpa_score = sample(1:100, nobs, replace = T)

#create mother id: random draw with average of 2
dat$mother_id = sample(1:(nobs/2), nobs, replace = T)

#create mother id: random draw with average of 2
dat$stanine_score = sample(1:9, nobs, replace = T)
dat$stanine_score = ifelse(dat$Gender == "Girls", NA, dat$stanine_score)

###############################Simulated death register data########################################
daar = dat %>% 
  filter(early_death == 1) %>% 
  select(pid)

n_death = nrow(daar)

#generate cause of death: 65 categories: EU shortlist 2012
daar$Code = sample(1:65, n_death, replace = T)

daar = daar %>% 
  mutate(cod = case_when(
    Code == 63 ~ "Suicide or self-harm",
    Code %in% 1:5 ~ "Infectious and parasitic diseases",
    Code %in% 6:24 ~ "Neoplasms",
    Code %in% 25:28 ~ "Other diseases",
    Code %in% 31:57 ~ "Other diseases",
    Code %in% 58:65 ~ "External causes of injury and poisoning",
    Code %in% 29:30 ~ "External causes of injury and poisoning"
  ))

