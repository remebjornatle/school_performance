###########################GPA MODEL############################################
#FIGURE1

#simple Cox model only using gender and GPA
gpa_mod = coxph(Surv(lifetime, early_death) ~ gpa_q*Gender, data = dat)

#create frame to attach predictions: predict number of events from graduation to 30-years old
gpa = dat %>% 
  ungroup() %>% 
  select(gpa_q, Gender) %>% 
  group_by(gpa_q,Gender) %>% 
  slice(1) %>% #one unique registration per group
  mutate(lifetime = 5110, #lifetime: 01/01/2019 - graduation_date, i.e. surviving until 30 yrs
         early_death = 0) 

#predict on frame
gpa_fit = predict(gpa_mod, type = "expected", newdata = gpa, se.fit = T)

#unlist to create 95% CIs
gpa_fit = gpa_fit %>% 
  map(unlist) %>% 
  as_data_frame() %>% 
  mutate(ul = fit + 2*se.fit,
         ll = fit - 2*se.fit)

#merge onto frame
gpa = bind_cols(gpa, gpa_fit)

##################################GPA GRAPH#####################################

#graph results
gpa_plot = gpa %>% 
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls")),
         gpa_q = factor(gpa_q,
                        levels =  c("GPA Q1", 
                                    "GPA Q2",
                                    "GPA Q3",
                                    "GPA Q4"),
                        labels = c("Q1","Q2","Q3","Q4"))) %>% 
  filter(!is.na(gpa_q)) %>% 
  ggplot(aes(x = reorder(gpa_q, -fit), y = round(fit*10000,0),fill = Sex)) +
  geom_col(color = "black", width = 0.5, position = "dodge") +
  theme_bw() +
  geom_errorbar(aes(ymin=ll*10000, ymax=ul*10000),
                width=.2,                    # Width of the error bars
                position=position_dodge(.5)) +
  xlab("School GPA quartile") +
  ylab("Events per 10 000") +
  scale_fill_lancet() +
  theme_bw() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"),
        legend.position = "none")
ggsave("tables and figures/GPA_cox.pdf",  width = 6, height = 4) 


##################################GPA TABLE#####################################

gpa_tab = gpa %>% 
  mutate(Sex = factor(Gender, levels = c("Boys", "Girls")),
         gpa_q = factor(gpa_q,
                        levels =  c("GPA Q1", 
                                    "GPA Q2",
                                    "GPA Q3",
                                    "GPA Q4"),
                        labels = c("Q1","Q2","Q3","Q4"))) %>% 
  filter(!is.na(gpa_q)) %>% 
  mutate(estimate = round(fit*10000,2),
         ul = round(ul*10000,2),
         ll = round(ll*10000,2)) %>% 
  select(gpa_q, Gender, estimate, ll, ul)

write.csv(gpa_tab, "tables and figures/gpa_tab.csv", row.names = F)  
