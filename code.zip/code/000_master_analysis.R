
#NOTE: This code runs on simulated data. Hence, the results in paper cannot be 
#reproduced with this code.

#run this line to load packages and generate a dummy-dataset
source("00_prep.R")
file.edit("00_prep.R")



###########################MAIN ANALYSIS########################################
#Note: Unless specifically noted - these can be run as separate modules

#GPA model: Fig 1a and table S2
source("01_analysis_GPA_model.R")
file.edit("01_analysis_GPA_model.R")

#Income model: Fig 1b and table S3
source("01_analysis_income_model.R")
file.edit("01_analysis_income_model.R")

#Education model: Fig 1c and table S4
source("01_analysis_education_model.R")
file.edit("01_analysis_education_model.R")

#Create Figure 1 - merge panels a, b and c (NOTE: requires previous 3 modules)
source("01_Figure1_combine.R")
file.edit("01_Figure1_combine.R")

#Combined GPA, Income and education: Figure 2 and table S5
source("01_analysis_combined_models.R")
file.edit("01_analysis_combined_models.R")

#Cause of death analysis: Figure 3 and 4; Table S8 and S9
source("01_analysis_COD_models.R")
file.edit("01_analysis_COD_models.R")

########################ROBUSTNESS/SUPPLEMENTARY################################

#Fig S6 and table S7: Stanine analysis
source("02_analysis_stanine_models.R")
file.edit("02_analysis_stanine_models.R")

#Fig S4: Assess proportional hazard assumption: median split of event window
source("02_analysis_coxPH_median_split.R")
file.edit("02_analysis_coxPH_median_split.R")

#Fig S3: GPA deciles: use deciles of GPA instead of quartiles
source("02_analysis_GPA_model_deciles.R")
file.edit("02_analysis_GPA_model_deciles.R")

#Fig S5 and table S6: Within family model
###Warning! - this code cuts sample - rerun "00_prep.R" afterwards
source("02_analysis_sibling_models.R")
file.edit("02_analysis_sibling_models.R")

###########Comment to remaining analysis in the supplementary material##########
# Including missing: "NA" was included as separate factor level
# Father income rank: family income quartile replaced with paternal inc quartile
