1. System requirements
The analysis was done and tested on a Windows Server 2019 Standard PC
with Rstudio R version 4.1.2

2. Installation guide
- Rstudio can be installed from https://posit.co/download/rstudio-desktop/
- R can be installed from https://cran.r-project.org/mirrors.html

3. Demo
- To run the code on data please do the following 
 (1) Double-click "000_master_analysis.R" to open it. This file sources all R-files
     used for the analysis.  
     Note: Important to open Rstudio by double-clicking to set path correctly (see also (2)),
     and that Rstudio is set as the default program for all ".R" files.
 (2) run "source("00_prep.R")" code block within "000_master_analysis.R". 
     To check the path is set correctly, write "here()" and see that the code
     folder is the working directory of RStudio
 (3) run the analysis required using "source"-lines, for each part,
     while the "file.edit"-lines can be used to inspect the code
 - Expected output: tables and graphs in the "tables and figures" folder.
 - Expected runtime on a normal computer: 1 minute (was 52s on an HP Elitebook i7 8th gen)

4: Instructions for use
 - The software can be run on data using the procedure described in (3) above.

Note: Data is randomly generated - hence, the results from the paper will not reproduce.
